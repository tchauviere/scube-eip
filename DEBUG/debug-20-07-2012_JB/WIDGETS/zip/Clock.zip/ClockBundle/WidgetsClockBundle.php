<?php

namespace Widgets\ClockBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WidgetsClockBundle extends Bundle
{
}
