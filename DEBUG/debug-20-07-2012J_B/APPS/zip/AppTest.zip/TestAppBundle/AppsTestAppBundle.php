<?php

namespace Apps\TestAppBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AppsTestAppBundle extends Bundle
{
}
