<?php

namespace Widgets\SimpleClockBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WidgetsSimpleClockBundle extends Bundle
{
}
