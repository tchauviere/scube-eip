<?php

namespace Scube\FriendsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ScubeFriendsBundle extends Bundle
{
}
